

set -o errexit
set -o errtrace
set -o pipefail

__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export ENVIRONMENT=TEST
[[ -f "${__DIR}/pipeline.sh" ]] && source "${__DIR}/pipeline.sh" ||  \
 echo "No pipeline.sh found"
prodTag="$(findLatestProdTag)"
echo "Last prod tag equals [${prodTag}]"
if [[ -z "${prodTag}" ]]; then
	echo "No prod release took place - skipping this step"
else

	"${GIT_BIN}" checkout "${prodTag}"
	testRollbackDeploy "${prodTag}"
fi
