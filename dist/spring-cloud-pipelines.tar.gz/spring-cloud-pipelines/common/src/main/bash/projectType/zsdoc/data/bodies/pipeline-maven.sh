

set -o errexit
set -o errtrace
set -o pipefail

export MAVENW_BIN
MAVENW_BIN="${MAVENW_BIN:-./mvnw}"
if [[ ${BUILD_OPTIONS} != *"java.security.egd"* ]]; then
	if [[ ! -z ${BUILD_OPTIONS} && ${BUILD_OPTIONS} != "null" ]]; then
		export BUILD_OPTIONS="${BUILD_OPTIONS} -Djava.security.egd=file:///dev/urandom"
	else
		export BUILD_OPTIONS="-Djava.security.egd=file:///dev/urandom"
	fi
fi

export -f build
export -f retrieveAppName
export -f retrieveGroupId
export -f executeApiCompatibilityCheck
export -f runSmokeTests
export -f runE2eTests
export -f outputFolder
export -f testResultsAntPattern
