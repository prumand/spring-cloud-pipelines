

set -o errexit
set -o errtrace
set -o pipefail

export COMPOSER_BIN PHP_BIN
COMPOSER_BIN="${COMPOSER_BIN:-composer}"
PHP_BIN="${PHP_BIN:-php}"
APT_BIN="${APT_BIN:-apt-get}"
ADD_APT_BIN="${ADD_APT_BIN:-add-apt-repository}"
TAR_BIN="${TAR_BIN:-tar}"
CURL_BIN="${CURL_BIN:-curl}"
BINARY_EXTENSION="${BINARY_EXTENSION:-tar.gz}"

export ARTIFACT_TYPE
ARTIFACT_TYPE="${SOURCE_ARTIFACT_TYPE_NAME}"
export DOWNLOADABLE_SOURCES
DOWNLOADABLE_SOURCES="true"
