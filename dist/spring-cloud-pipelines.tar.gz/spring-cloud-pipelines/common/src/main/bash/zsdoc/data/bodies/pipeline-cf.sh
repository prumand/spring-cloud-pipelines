

set -o errexit
set -o errtrace
set -o pipefail
export RETRIEVE_STUBRUNNER_IDS_FUNCTION="${RETRIEVE_STUBRUNNER_IDS_FUNCTION:-retrieveStubRunnerIds}"

export CF_BIN
CF_BIN="${CF_BIN:-cf}"
