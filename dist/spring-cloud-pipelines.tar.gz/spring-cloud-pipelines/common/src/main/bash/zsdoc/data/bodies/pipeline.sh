

set -o errexit
set -o errtrace
set -o pipefail

IFS=$' \n\t'

__ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PIPELINE_DESCRIPTOR PAAS_TYPE LOWERCASE_ENV GIT_BIN
export ROOT_PROJECT_DIR PROJECT_SETUP PROJECT_NAME DEFAULT_PROJECT_NAME
export LANGUAGE_TYPE SOURCE_ARTIFACT_TYPE_NAME BINARY_ARTIFACT_TYPE_NAME
export OUTPUT_FOLDER TEST_REPORTS_FOLDER DOWNLOADABLE_SOURCES
SOURCE_ARTIFACT_TYPE_NAME="source"
BINARY_ARTIFACT_TYPE_NAME="binary"
PAAS_TYPE="$( toLowerCase "${PAAS_TYPE:-cf}" )"
LOWERCASE_ENV="$(toLowerCase "${ENVIRONMENT}")"
PIPELINE_DESCRIPTOR="${PIPELINE_DESCRIPTOR:-sc-pipelines.yml}"
GIT_BIN="${GIT_BIN:-git}"
DEFAULT_PROJECT_NAME="$(basename "$(pwd)")"
echo "Picked PAAS is [${PAAS_TYPE}]"
echo "Current environment is [${ENVIRONMENT}]"
echo "Project name [${PROJECT_NAME}]"
parsePipelineDescriptor
defineProjectSetup
__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ -f "${__DIR}/projectType/pipeline-projectType.sh" ]] && source "${__DIR}/projectType/pipeline-projectType.sh" ||  \
 echo "No projectType/pipeline-projectType.sh found"
LANGUAGE_TYPE="$(toLowerCase "${LANGUAGE_TYPE}")"
if [[ "${PROJECT_NAME}" == "" || "${PROJECT_NAME}" == "null" ]]; then
	PROJECT_NAME="$(retrieveAppName)"
fi
echo "Project with name [${PROJECT_NAME}] is setup as [${PROJECT_SETUP}]. The project directory is present at [${ROOT_PROJECT_DIR}]"
[[ -f "${__ROOT}/pipeline-${PAAS_TYPE}.sh" ]] && source "${__ROOT}/pipeline-${PAAS_TYPE}.sh" ||  \
 echo "No pipeline-${PAAS_TYPE}.sh found"
export CUSTOM_SCRIPT_IDENTIFIER="${CUSTOM_SCRIPT_IDENTIFIER:-custom}"
echo "Custom script identifier is [${CUSTOM_SCRIPT_IDENTIFIER}]"
CUSTOM_SCRIPT_DIR="${__ROOT}/${CUSTOM_SCRIPT_IDENTIFIER}"
mkdir -p "${__ROOT}/${CUSTOM_SCRIPT_IDENTIFIER}"
CUSTOM_SCRIPT_NAME="$(basename "${BASH_SOURCE[1]}")"
echo "Path to custom script is [${CUSTOM_SCRIPT_DIR}/${CUSTOM_SCRIPT_NAME}]"
[[ -f "${CUSTOM_SCRIPT_DIR}/${CUSTOM_SCRIPT_NAME}" ]] && source "${CUSTOM_SCRIPT_DIR}/${CUSTOM_SCRIPT_NAME}" ||  \
 echo "No ${CUSTOM_SCRIPT_DIR}/${CUSTOM_SCRIPT_NAME} found"

OUTPUT_FOLDER="$(outputFolder)"
TEST_REPORTS_FOLDER="$(testResultsAntPattern)"

echo "Output folder [${OUTPUT_FOLDER}]"
echo "Test reports folder [${TEST_REPORTS_FOLDER}]"
